#account_sid = 'AC18a570f80d2841197c103f75cf3266d3'
#auth_token = '5852710150bb8a7b8c3bc29054975c20'
#my_cell = '+918544309046 '
#my_twilio = '+12028167197'

account_sid = 'RaspberryPi'
auth_token = '233769A3q987o49BQ5b825fa7'
my_cell = '+918544309046'
#my_twilio = '+12028167197'
