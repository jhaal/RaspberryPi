#! /usr/bin/python2.7
import urllib
import urllib2
import time
import datetime

now = datetime.datetime.now()

authkey = "your/authentication/key"
mobiles = "enter/mobile/numbers/separated by comma"
message = now.strftime("Reboot Successful on my RaspberryPi at %d-%m-%y %H:%M:%S)
sender = "6-digit alphanumeric authkey"
route = "route no. obtained from msg91"
# Prepare you post parameters
values = {
          'authkey' : authkey,
          'mobiles' : mobiles,
          'message' : message,
          'sender' : sender,
          'route' : route
          }
url = "http://api.msg91.com/api/sendhttp.php" # API URL
postdata = urllib.urlencode(values) # URL encoding the data here.
req = urllib2.Request(url, postdata)
response = urllib2.urlopen(req)
output = response.read() # Get Response
#print output # Print Response - optional.
