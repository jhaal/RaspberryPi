<?php

// User settings
// Edit the parameters in this file to cusomise your KitchenTV


// ##### ASPECT ####
// If your TV aspect is more sqaure than regular widescreen you can use the 4:3 mode
// m43 = 4:3 aspect, m169 = 16:9 aspect
// $aspect ="m43";
$aspect ="m169";

// ##### Date / Timezone #####
// You can safely disable my default timezone by adding // to the start of the line.
date_default_timezone_set("Asia/Mumbai"); 
// You do not need to edit this unless you know what you are doing.
$date= strtoupper(date("M jS l", time()));

// ##### Weather #####
// see weather.js file
// weather location - examples: "Manchester, England", "Paris, Texas", "Paris, France"
// or check on Yahoo weather if you have trouble,
$wloc="Mumbai";
// weather forecast days, MAX 9
$wdays=4;
// Temperature units; C or F
$wunit = "C";

// ##### IP Checker, 0=off 1=on #####
$ipchecker=0;

// ##### Your IP address #####
// You need to update this if your IP changes to turn off the on-screen warining
// To check your ip visit whatismyip.com
$ip="117.207.221.70";

// alternate file method - just create this text file with your IP & nothing else.
//$ip=file_get_contents('ip.txt');

// ##### YouTube #####
// Video streams
// name = a short name or abreviation to help you remmeber the channel. A 2 letter code is recommended; BB, FR, MC
// url = the youtube video ID
// time = to display the video in seconds
// mus = 0 or 1. mus=0 channels will switch between each other, as will mus=1, but they wont cross over unless you manually click.
// Its is designed to have MUSIC separate from other content. So you can put the Kitchen TV into music mode.

// Explore - LIVE TRAIN
$streams[]=array(
  "name" => "Train",
  "url" => "5KKyy9J1IxU", 
  "time" => 600,
  "mus" => 0
);
// explore- Tropical Reef camera
$streams[]=array(
   "name" =>"REEF",
   "url" => "afQwJ_OrJbw", 
   "time" => 600,
   "mus" => 0
);
// AaJ Tak
$streams[]=array(
    "name" => "AajTak",
    "url" => "gHykKPYuWvs",
    "time" => 1200,
    "mus" => 0
);
// DD_NEWS
$streams[]=array(
    "name" => "DD",
    "url" => "aN8dZGVJKg4",
    "time" => 1200,
    "mus" => 0
);
//RSTV
$streams[]=array(
    "name" => "RSTV",
    "url"  => "hCnSg7z--j4",
    "time" => 1200,
    "mus"  => 0
);
// INDIA TV
//$streams[]=array(
//   "name" => "India_TV",
//   "url" => "4WI_gpwbIEs", 
//   "time" => 600,
//   "mus" => 0
//);
// SONY LIV
//$streams[]=array(
//   "name" => "India_TV",
//   "url" => "4WI_gpwbIEs", 
//   "time" => 7200,
//   "mus" => 0
//);
// Sky News
$streams[]=array(
    "name" => "SkyNews",
    "url" => "XOacA3RYrXk",
    "time" => 600,
    "mus" => 0
);
// Monstercat
$streams[]=array(
	"name" => "MC",
	"url"  => "ueupsBPNkSc",
	"time" => 240,
	"mus"  => 0
);
// Nasa live
$streams[]=array(
    "name" => "NS",
    "url" => "ddFvjfvPnqk",
    "time" => 240,
    "mus" => 0
);
//
//
// Some channels change their url frequently, so watch out for that & pick what works for you.
// ##### News Feed #####
// url of RSS news feed
// this works off <title> <description> & <link> so those elements must be present in the XML doc

$news_url="http://www.aljazeera.com/xml/rss/all.xml";
$news_url="http://feeds.bbci.co.uk/news/rss.xml?edition=uk";
$news_url="http://feeds.bbci.co.uk/news/world/us_and_canada/rss.xml";
$news_url="https://news.google.com/news?cf=all&hl=en&pz=1&ned=us&output=rss";
$news_url="http://www.techradar.com/rss";
//$news_url="http://www.thehindubusinessline.com/?service=rss";

// ###### Weather Underground alerts ####
// your local weather station page to extract alerts from
// $wupage="https://www.wunderground.com/q/zmw:90001.1.99999";
$wupage="https://www.wunderground.com/q/zmw:IMAHARAS29";
// uncomment "wu_advisory" on index.php to start using

?>
