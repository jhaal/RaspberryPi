<html>
<head>
    <meta charset="utf-8">
    <link rel="stylesheet" href="main.css">
</head>
<body>
 <div id="nav">
                      <ul>
                  <a href="index.php"><li class="btn2">&lt;</li></a>
            </ul>

<iframe id="web_frame" src="http://duckduckgo.com"></iframe>
</body>
</html>
    